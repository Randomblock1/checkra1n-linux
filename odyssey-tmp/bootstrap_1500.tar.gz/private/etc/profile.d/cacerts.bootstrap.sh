## git ##
git config --global http.sslCAInfo /etc/ssl/certs/cacert.pem >/dev/null 2>&1
